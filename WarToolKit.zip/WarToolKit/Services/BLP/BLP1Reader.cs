﻿using System;
using System.IO;

namespace WarToolKit.Services
{
    public class BLP1Reader : IBLPReader
    {
        public BLPHeader ReadHeader(string file)
        {
            using var reader = new BinaryReader(File.OpenRead(file));

            var header = new BLPHeader();

            header.Magic = new string(reader.ReadChars(4));

            if (header.Magic != "BLP1")
                throw new InvalidDataException("Not a BLP1 file.");

            header.Version = 1;

            header.Compression = reader.ReadInt32();
            header.AlphaBits = reader.ReadInt32();
            header.Width = reader.ReadInt32();
            header.Height = reader.ReadInt32();

            header.HasMipmaps = true;

            header.MipOffsets = new int[16];
            header.MipSizes = new int[16];

            for (int i = 0; i < 16; i++)
                header.MipOffsets[i] = reader.ReadInt32();

            for (int i = 0; i < 16; i++)
                header.MipSizes[i] = reader.ReadInt32();

            return header;
        }

        public byte[] ReadFirstMip(string file)
        {
            var header = ReadHeader(file);

            using var reader = new BinaryReader(File.OpenRead(file));

            reader.BaseStream.Position = header.MipOffsets[0];

            return reader.ReadBytes(header.MipSizes[0]);
        }
    }
}