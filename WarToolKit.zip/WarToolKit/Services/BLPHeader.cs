﻿namespace WarToolKit.Services
{
    public enum BLPCompression
    {
        JPEG = 0,
        PALETTE = 1,
        DXT = 2,
        UNKNOWN = 255
    }

    public class BLPHeader
    {
        public string Magic { get; set; } = "";

        public int Version { get; set; }

        public BLPCompression Compression { get; set; }

        public byte AlphaBits { get; set; }

        public int Width { get; set; }

        public int Height { get; set; }

        public bool HasMipmaps { get; set; }

        public int[] MipOffsets { get; set; } = new int[16];

        public int[] MipSizes { get; set; } = new int[16];
    }
}