﻿namespace WarToolKit.Services
{
    public enum BLPCompression
    {
        JPEG = 0,
        PALETTE = 1,
        DXT = 2,
        UNKNOWN = 255
    }
}