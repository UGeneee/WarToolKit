﻿using System.IO;

namespace WarToolKit.Services
{
    public enum BLPCompression
    {
        JPEG = 0,
        Direct = 1
    }

    public class BLPHeader
    {
        public string Magic { get; set; } = "";
        public int Version { get; set; }

        public BLPCompression Compression { get; set; }

        public byte AlphaBits { get; set; }

        public byte AlphaEncoding { get; set; }

        public bool HasMipmaps { get; set; }

        public int Width { get; set; }

        public int Height { get; set; }

        public int[] MipOffsets { get; } = new int[16];

        public int[] MipSizes { get; } = new int[16];
    }

    public class BLP2Reader : IBLPReader
    {
        public BLPHeader ReadHeader(string file)
        {
            using var reader = new BinaryReader(File.OpenRead(file));

            var header = new BLPHeader();

            header.Magic = new string(reader.ReadChars(4));

            if (header.Magic != "BLP2")
                throw new InvalidDataException("Only BLP2 is supported.");

            header.Version = 2;

            header.Compression =
                (BLPCompression)reader.ReadByte();

            header.AlphaBits =
                reader.ReadByte();

            header.AlphaEncoding =
                reader.ReadByte();

            header.HasMipmaps =
                reader.ReadByte() != 0;

            header.Width =
                reader.ReadInt32();

            header.Height =
                reader.ReadInt32();

            for (int i = 0; i < 16; i++)
                header.MipOffsets[i] = reader.ReadInt32();

            for (int i = 0; i < 16; i++)
                header.MipSizes[i] = reader.ReadInt32();

            return header;
        }
        public byte[] ReadFirstMip(string file)
        {
            var header = ReadHeader(file);

            using var reader = new BinaryReader(File.OpenRead(file));

            reader.BaseStream.Position = header.MipOffsets[0];

            return reader.ReadBytes(header.MipSizes[0]);
        }
    }
}