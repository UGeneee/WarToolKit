﻿using System.Windows;
using WarToolKit.Parsers;
using WarToolKit.Services;
using System.IO;
using System.Windows;
using DataFormats = System.Windows.DataFormats;

namespace WarToolKit
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private readonly MDXParser mdxParser = new();

        private readonly FileScanner scanner = new();


        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_DragOver(object sender, System.Windows.DragEventArgs e)
        {
            if (e.Data.GetDataPresent(System.Windows.DataFormats.FileDrop))
            {
                e.Effects = System.Windows.DragDropEffects.Copy;
            }
            else
            {
                e.Effects = System.Windows.DragDropEffects.None;
            }

            e.Handled = true;
        }

        private void Window_Drop(object sender, System.Windows.DragEventArgs e)
        {
            if (!e.Data.GetDataPresent(System.Windows.DataFormats.FileDrop))
                return;

            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop)!;

            foreach (string file in files)
            {
                if (Path.GetExtension(file).Equals(".mdx", StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        var model = mdxParser.Read(file);

                        string text =
                            $"Model: {model.Name}\n" +
                            $"Version: {model.Version}\n\n";

                        foreach (string tex in model.Textures)
                        {
                            text += tex + "\n";
                        }

                        System.Windows.MessageBox.Show(text);
                    }
                    catch (Exception ex)
                    {
                        System.Windows.MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        private void OpenFolder_Click(object sender, RoutedEventArgs e)
        {
            using FolderBrowserDialog dialog = new();

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                var files = scanner.ScanFolder(dialog.SelectedPath);

                FileList.ItemsSource = files;

                StatusText.Text = "Folder loaded successfully.";
                FolderPathText.Text = dialog.SelectedPath;

                FileCountText.Text = $"{files.Count} Files";
                FolderFileCount.Text = $"{files.Count} texture files";
            }

        }

        private void FileList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (FileList.SelectedItem is Models.TextureFile texture)
            {
                PreviewPanel.Display(texture);
            }

        }

    }
}