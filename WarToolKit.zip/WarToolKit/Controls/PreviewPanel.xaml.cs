﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using WarToolKit.Models;
using WarToolKit.Services;

namespace WarToolKit.Controls
{
    public partial class PreviewPanel : System.Windows.Controls.UserControl
    {
        private readonly BLPReader reader = new();

        public PreviewPanel()
        {
            InitializeComponent();
        }

        public void Display(TextureFile texture)
        {
            FileNameText.Text = texture.Name;
            SizeText.Text = $"Size: {texture.FormattedFileSize}";
            PreviewImage.Source = null;

            try
            {
                // ===========================
                // STEP 1 - Read the first 4 bytes
                // ===========================
                using (var fs = File.OpenRead(texture.FullPath))
                using (var br = new BinaryReader(fs))
                {
                    string magic = new string(br.ReadChars(4));

                    System.Windows.MessageBox.Show(
                        $"Magic Header:\n\n{magic}",
                        "BLP Debug");
                }

                // ===========================
                // STEP 2 - Read the BLP header
                // ===========================
                var info = reader.ReadHeader(texture.FullPath);

                ResolutionText.Text =
                    $"Resolution: {info.Width} x {info.Height}";

                FormatText.Text =
                    $"Format: BLP{info.Version} ({info.Compression})";

                // ===========================
                // STEP 3 - Read first mipmap
                // ===========================
                var mip = reader.ReadFirstMip(texture.FullPath);

                System.Windows.MessageBox.Show(
                    $"First mipmap size:\n\n{mip.Length} bytes",
                    "BLP Debug");
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(
                    ex.ToString(),
                    "ERROR");

                ResolutionText.Text = "Resolution: Unknown";
                FormatText.Text = "Format: Invalid";
            }
        }
    }
}